<?php

namespace Database\Seeders;

use App\Models\Order;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class OrderSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        /*
        |--------------------
        | Order
        |--------------------
        |
        | Hàm bổ sung:
        | - createOrderItems(...) : Tạo thêm các OrderItems con.
        |
        */
        Order::factory()
            ->count(10)
            ->createOrderItems(1)
            ->create();
    }
}
