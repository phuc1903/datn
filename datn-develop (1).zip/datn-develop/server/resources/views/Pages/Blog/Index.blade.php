@extends('layouts.app')

@section('content')
    <h1>Blog</h1>
@endsection
