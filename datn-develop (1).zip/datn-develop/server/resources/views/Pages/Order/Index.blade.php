@extends('layouts.app')

@section('content')
    <h1>Order</h1>
@endsection
