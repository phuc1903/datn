@extends('layouts.app')

@section('content')
    <h1>Biến thể</h1>
@endsection
