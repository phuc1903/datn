@extends('layouts.app')

@section('content')
    <h1>Voucher</h1>
@endsection
