<?php

return [
    'api_url' => 'https://documenter.getpostman.com/view/27137333/2sAYQanrW6',
    'image_default' => 'image/default.jpg', // Không dùng asset() ở đây
];


?>